function toBoolean(param) {
	return Boolean(param);

}

console.log(toBoolean(20));
console.log(toBoolean(''));